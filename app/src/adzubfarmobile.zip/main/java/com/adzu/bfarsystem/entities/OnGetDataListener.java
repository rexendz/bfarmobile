package com.adzu.bfarsystem.entities;

import com.google.firebase.database.DataSnapshot;

public interface OnGetDataListener {
    void onRetrieve(DataSnapshot dataSnapshot);
    void onSuccess(DataSnapshot dataSnapshot);
    void onStart();
    void onFailure();
}
