package com.adzu.bfarsystem.entities;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.adzu.bfarsystem.MainActivity;
import com.adzu.bfarsystem.R;

import java.util.List;

public class OperatorAdapter extends RecyclerView.Adapter<OperatorAdapter.OperatorViewHolder> {

    private Context ctx;
    private List<FishpondOperator> fishpondOperator;

    public OperatorAdapter(Context ctx, List<FishpondOperator> operatorList) {
        this.ctx = ctx;
        this.fishpondOperator = operatorList;
    }

    @NonNull
    @Override
    public OperatorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View view = inflater.inflate(R.layout.list_layout, null);
        return new OperatorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OperatorViewHolder holder, int position) {
        FishpondOperator operator = fishpondOperator.get(position);
        holder.text_name.setText("Name: " + operator.getFullName());
        holder.text_opnum.setText("Operator #: " + (int) operator.getOperator_number());
        holder.text_flanum.setText("FLA #: " + operator.getFla_number());
        holder.text_address.setText("Address: " + operator.getAddress());
    }

    @Override
    public int getItemCount() {
        return fishpondOperator.size();
    }

    class OperatorViewHolder extends RecyclerView.ViewHolder{

        TextView text_name;
        TextView text_opnum;
        TextView text_flanum;
        TextView text_address;
        TextView text_status;

        public OperatorViewHolder(@NonNull View itemView) {
            super(itemView);

            text_name = itemView.findViewById(R.id.text_name);
            text_opnum = itemView.findViewById(R.id.text_opnum);
            text_status = itemView.findViewById(R.id.text_status);
            text_address = itemView.findViewById(R.id.text_address);
            text_flanum = itemView.findViewById(R.id.text_flanum);
        }
    }
}
