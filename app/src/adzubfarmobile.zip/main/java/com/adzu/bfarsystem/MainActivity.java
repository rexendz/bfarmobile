package com.adzu.bfarsystem;

import android.os.Bundle;

import com.adzu.bfarsystem.entities.FishpondOperator;
import com.adzu.bfarsystem.entities.OperatorAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    List<FishpondOperator> operatorList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FishpondOperator op1 = new FishpondOperator();
        op1.setFla_number(123);
        op1.setFirstname("Rex");
        op1.setMiddlename("Royo");
        op1.setLastname("Endozo");
        op1.setBarangay("Tumaga");
        op1.setCityProvince("Zamboanga City");
        op1.setOperator_number(15);

        FishpondOperator op2 = new FishpondOperator();
        op2.setFla_number(124);
        op2.setFirstname("Xer");
        op2.setMiddlename("Rasd");
        op2.setLastname("Mio");
        op2.setBarangay("Taguig");
        op2.setCityProvince("Zamboanga Cebugay");
        op2.setOperator_number(16);

        operatorList = new ArrayList<>();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        operatorList.add(op1);
        operatorList.add(op2);
        operatorList.add(op2);
        operatorList.add(op1);
        operatorList.add(op1);
        operatorList.add(op1);
        operatorList.add(op1);
        operatorList.add(op1);
        operatorList.add(op1);
        operatorList.add(op1);
        operatorList.add(op1);

        OperatorAdapter operatorAdapter = new OperatorAdapter(this, operatorList);

        recyclerView.setAdapter(operatorAdapter);


    }
}