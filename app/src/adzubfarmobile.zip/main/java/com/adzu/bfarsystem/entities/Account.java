package com.adzu.bfarsystem.entities;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.security.NoSuchAlgorithmException;

public class Account {
    private String firstname;
    private String middlename;
    private String lastname;
    private String username;
    private String password;
    private boolean activated;
    private boolean admin;
    private boolean root;
    private boolean grantPrivilege;
    private String activated_by;
    private String made_admin_by;
    private String removed_admin_by;

    public Account(){
        this.activated = false;
        this.admin = false;
        this.root = false;
        this.grantPrivilege = false;
        this.activated_by = "NONE";
        this.made_admin_by = "NONE";
        this.removed_admin_by = "NONE";
    }

    public boolean isGrantPrivilege() {
        return grantPrivilege;
    }

    public boolean isActivated() {
        return activated;
    }

    public boolean isAdmin() {
        return admin;
    }

    public boolean isRoot() {
        return root;
    }

    public void setGrantPrivilege(boolean privilege){
        this.grantPrivilege = privilege;
    }

    public String getUsername() {
        return username;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setPasswordHashed(){
        String salt = PasswordEncryption.generateSalt(50).get();
        String key = PasswordEncryption.hashPassword(password, salt).get();
        System.out.println("Salt "+ salt+ " length: "+salt.length());
        this.password = salt+key;
    }

    public String getPassword() {
        return password;
    }

    public String getActivated_by() {
        return activated_by;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getMade_admin_by() {
        return made_admin_by;
    }

    public String getMiddlename() {
        return middlename;
    }

    public String getRemoved_admin_by() {
        return removed_admin_by;
    }

    public void setActivated(boolean activated) {
        this.activated = activated;
    }

    public void setActivated_by(String activated_by) {
        this.activated_by = activated_by;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setMade_admin_by(String made_admin_by) {
        this.made_admin_by = made_admin_by;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRemoved_admin_by(String removed_admin_by) {
        this.removed_admin_by = removed_admin_by;
    }

    public void setRoot(boolean root) {
        this.root = root;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
