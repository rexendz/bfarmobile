package com.adzu.bfarsystem;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.adzu.bfarsystem.entities.Account;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.NoSuchAlgorithmException;


public class SignupActivity extends AppCompatActivity {
    private ConstraintLayout signupLayout;
    private AnimationDrawable animDrawable;
    private DatabaseReference databaseReference;

    private ProgressDialog mProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        databaseReference = FirebaseDatabase.getInstance().getReference("account");

        signupLayout = findViewById(R.id.signup_layout);
        animDrawable = (AnimationDrawable) signupLayout.getBackground();
        animDrawable.setEnterFadeDuration(10);
        animDrawable.setExitFadeDuration(5000);
        animDrawable.start();

        mProgress = new ProgressDialog(this);
        mProgress.setTitle("Processing...");
        mProgress.setMessage("Please wait...");
        mProgress.setCancelable(false);
        mProgress.setIndeterminate(true);
    }

    public Context getContext(){
        return this;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void signup_action(View view){
        final Account user = new Account();
        final EditText field_firstname = findViewById(R.id.field_firstname);
        final EditText field_middlename = findViewById(R.id.field_middlename);
        final EditText field_lastname = findViewById(R.id.field_lastname);
        final EditText field_user = findViewById(R.id.field_user);
        final EditText field_pass = findViewById(R.id.field_pass);
        final EditText field_cpass = findViewById(R.id.field_cpass);
        user.setFirstname(field_firstname.getText().toString());
        user.setMiddlename(field_middlename.getText().toString());
        user.setLastname(field_lastname.getText().toString());
        user.setUsername(field_user.getText().toString());
        user.setPassword(field_pass.getText().toString());

        if(field_firstname.getText().toString().isEmpty() || field_middlename.getText().toString().isEmpty() || field_lastname.getText().toString().isEmpty() || field_user.getText().toString().isEmpty() || field_pass.getText().toString().isEmpty()){
            Toast.makeText(getApplicationContext(), "Please fill up the missing fields.", Toast.LENGTH_LONG).show();
        }

        else if (!field_pass.getText().toString().equals(field_cpass.getText().toString())) {
            field_cpass.setError("Password does not match!");
            field_cpass.requestFocus();
        }
        else {
            final boolean[] isRegistered = {false};
            mProgress.show();
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("account");
            ref.orderByChild("username").equalTo(field_user.getText().toString()).addValueEventListener(new ValueEventListener() {

                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        if(isRegistered[0] == false)
                            field_user.setError("Username Already Taken");
                        field_user.requestFocus();
                        mProgress.dismiss();
                    }
                    else {
                        isRegistered[0] = true;
                        user.setPasswordHashed();
                        String id = databaseReference.push().getKey();
                        databaseReference.child(id).setValue(user);
                        user.setUsername(null);
                        user.setPassword(null);
                        field_user.setError(null);

                        AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
                        alert.setTitle("BFAR Registration");
                        alert.setMessage("Account Successfully Created!\nPlease contact the administrators for account activation.");
                        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent(getContext(), LoginActivity.class);
                                startActivity(intent);
                            }
                        });
                        mProgress.dismiss();
                        alert.show();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    mProgress.dismiss();
                    Log.d("FIREBASE", String.valueOf(databaseError));
                }
            });
        }
    }

    public void cancel_action(View view){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

}